<?php
defined('MOODLE_INTERNAL') || die();

$module->version   = 2014042301;
$module->requires  = 2012062507; // See http://docs.moodle.org/dev/Moodle_Versions
$module->cron      = 0;
$module->component = 'mod_aspirelists';
$module->maturity  = MATURITY_ALPHA;
$module->release   = '.0001';
