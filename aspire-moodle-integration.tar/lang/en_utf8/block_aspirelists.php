<?php
// Copyright (c) Talis Education Limited, 2010
// Released under the LGPL Licence - http://www.gnu.org/licenses/lgpl.html. Anyone is free to change or redistribute this code.

$string['config_targetAspire'] = 'Target Aspire base URL (e.g. \'http://lists.broadminsteruniversity.org\')';
$string['config_kg'] = 'Choose target knowledge group';
$string['blockname'] = 'Resource Lists';


?>
