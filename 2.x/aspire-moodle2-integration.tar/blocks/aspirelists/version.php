<?php
// Copyright (c) Talis Education Limited, 2011
// Released under the LGPL Licence - http://www.gnu.org/licenses/lgpl.html. Anyone is free to change or redistribute this code.

    $plugin->version = 2011090915;  // YYYYMMDDHH (year, month, day, 24-hr time)
    $plugin->requires = 2010112400; // YYYYMMDDHH (This is the release version for Moodle 2.0)
?>